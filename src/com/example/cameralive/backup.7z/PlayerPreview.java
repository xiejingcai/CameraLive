package com.example.cameralive;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

import android.app.Activity;
import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCodec.BufferInfo;
import android.media.MediaCodec.CodecException;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Bundle;
import android.os.Environment;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class PlayerPreview extends SurfaceView implements SurfaceHolder.Callback {

	private static final String SAMPLE = Environment.getExternalStorageDirectory() + "/video.mp4";
	
	public Player mPlayer = null;
	private SurfaceHolder mHolder = null;
	private Boolean isNeedExit = false;

	public PlayerPreview(Context context) {
		super(context);
		mHolder = getHolder();
		mHolder.addCallback(this);		
		// TODO Auto-generated constructor stub
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		// The Surface has been created, now tell the decoder where to draw the preview.
		Start();
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        // If your preview can change or rotate, take care of those events here.
        // Make sure to stop the preview before resizing or reformatting it.
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
	}
	
	public void Start(){
		if (mPlayer == null) {
			mPlayer = new Player(mHolder.getSurface());
		}
	}
	public void Stop(){
		if (mPlayer != null) {
			mPlayer.Exit();
		}
	}
		
	private class Player{	
		
		private Surface psurface;
		private MediaCodec decoder;
		private MediaFormat format;
		private BufferInfo info;
		
		private byte[] sample = null;
		private long pTS = 0;
		private int size = 0;
		private int type = 0;
		private byte[] h264startcode = {(byte)0,(byte)0,(byte)0,(byte)1};
		private byte[] sps;
		private byte[] pps;
		private int pTSdelta = 1000/MainActivity.mFps;
		
		private int codecconfig = 0;
		
		private boolean feedflag = true;
		
		public Player(Surface surface){
			
			Thread mThread = new Thread( new Runnable(){
				@Override
				public void run() {
					while(true){						
						try {
							Thread.sleep(33-8);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						feedflag = true;
					}
				}				
			});
			mThread.start();
			
			psurface = surface;
			
			try {
				decoder = MediaCodec.createDecoderByType(MainActivity.Vmimetype);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			format = MediaFormat.createVideoFormat(MainActivity.Vmimetype, MainActivity.mResolutionX,MainActivity.mResolutionY );
			format.setInteger(MediaFormat.KEY_ROTATION, 270);
			final long startMs = System.currentTimeMillis();
			
			decoder.setCallback(new MediaCodec.Callback(){

				@Override
				public void onInputBufferAvailable(MediaCodec codec, int index) {
					// TODO Auto-generated method stub
					//Log.e("onInputBufferAvailable","index="+index);
					
					feedData2Decoder(decoder,index);
				}

				@Override
				public void onOutputBufferAvailable(MediaCodec codec,
						int index, BufferInfo info) {
					Log.e("onOutputBufferAvailable","index="+index);	
					ByteBuffer outputBuffer = decoder.getOutputBuffer(index);
					decoder.releaseOutputBuffer(index, true);
				}

				@Override
				public void onError(MediaCodec codec, CodecException e) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void onOutputFormatChanged(MediaCodec codec,
						MediaFormat format) {
					// TODO Auto-generated method stub
				}}
			); 
			
			decoder.configure(format, psurface, null, 0);
			decoder.start();		
		}
		public void Exit(){
			decoder.stop();
			decoder.release();
		}
		private int tagDataParse(ByteBuffer buffer, byte[] tbf) {
			int nal_startpos = 5;// first nal start position, nal size
			int tbf_length = tbf.length;
			int sps_len = 0;
			int pps_len = 0;
			
			if (tbf[1] == 0) {// config, sps pps	
				codecconfig = 1;
				type = 0;
				size = tbf_length - 1;
				sps_len = ((tbf[11]&0xff)<<8)|(tbf[12]&0xff);
				pps_len = ((tbf[13+sps_len+1]&0xff)<<8)|(tbf[13+sps_len+2]&0xff);
				sps = new byte[sps_len+4];
				pps = new byte[pps_len+4];				
				System.arraycopy(h264startcode, 0, sps, 0, 4);
				System.arraycopy(tbf, 13, sps, 4, sps_len);
				System.arraycopy(h264startcode, 0, pps, 0, 4);
				System.arraycopy(tbf, 13+sps_len+3, pps, 4, pps_len);				
			} else if (tbf[1] == 1) {//nulu
				if(0x17==(tbf[0]&0xff)){//key frame
					type = 1;
				}else if(0x27==(tbf[0]&0xff)){//inter frame
					type = 2;
				}
				size = tbf_length-nal_startpos;
				System.arraycopy(h264startcode, 0, tbf, nal_startpos, 4);
				buffer.put(tbf);
			} else {				
				type = 3;
				size = 0;
			}
			pTS += 33000;
			return type;
		}
		
		public Boolean feedData2Decoder(MediaCodec codec,int index){
			if(!feedflag){
				return false;
			}else{
				feedflag = false;
			}
			sample = MainActivity.AVCQueue.poll();
			if (sample == null)
				return false;

			ByteBuffer buffer = codec.getInputBuffer(index);

			if(codecconfig==0)
				tagDataParse(buffer, sample);

			if (type == 0) {// config
				if(codecconfig==1){
					buffer.put(sps);
					decoder.queueInputBuffer(index, 0, sps.length, pTS,
							MediaCodec.BUFFER_FLAG_CODEC_CONFIG);
					codecconfig++;
				}else if(codecconfig==2){
					buffer.put(pps);
					decoder.queueInputBuffer(index, 0, pps.length, pTS,
							MediaCodec.BUFFER_FLAG_CODEC_CONFIG);
					codecconfig = 0;
				}
			} else if (type == 1) {// key frame
				decoder.queueInputBuffer(index, 5, size, pTS,
						MediaCodec.BUFFER_FLAG_KEY_FRAME);
			} else if (type == 2) {
				decoder.queueInputBuffer(index, 5, size, pTS, 0);
			}

			return true;
		}	
	}
}
